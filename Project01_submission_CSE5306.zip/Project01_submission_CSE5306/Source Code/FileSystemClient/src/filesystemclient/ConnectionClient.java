/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filesystemclient;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.io.OutputStream;
/**
 *
 * @author Wasiq Ali Abbasi
 */
public class ConnectionClient {
        final String host = "localhost";
		final int portNumber = 8080;
    private Socket socket;
    //private PrintWriter out;
    FileHandler fHandler=new FileHandler();
    public void EstablishClientConnection() throws Exception
    {
            socket=  new Socket(host, portNumber);
		//System.out.println("Creating socket to '" + host + "' on port " + portNumber);    
    }
    public void SendCommand(String command) throws Exception
            {
                PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                out.println(command);
                BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			System.out.println("[SERVER]:" + br.readLine());
//socket.close();
            }
    public void UploadFile() throws Exception
    {
        //fHandler= new FileHandler();
        byte[] mybytearray=fHandler.HandleUploadFile();
        System.out.println("[CLIENT]: Uploading file to Server");
        OutputStream os = null;
        os = socket.getOutputStream();
        os.write(mybytearray,0,mybytearray.length);
        os.flush();
        if (os != null) os.close();
    }
    public void DownloadFile() throws Exception
    {
        
        int bytesRead;
        byte [] mybytearray  = new byte [6022386];
        int current = 0;
        InputStream is = socket.getInputStream(); 
        do {
             bytesRead =
                is.read(mybytearray, current, (mybytearray.length-current));
             if(bytesRead >= 0) current += bytesRead;
           } while(bytesRead < -1);

        //fHandler=new FileHandler();
        fHandler.HandleDownloadFile(mybytearray, current);
    }
    public void RenameFile(String name) throws Exception
    {
         //socket=  new Socket(host, portNumber);
         PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
         out.println(name);
    }
    
    public void CloseClientConnection() throws Exception
    {
        socket.close();
    }
    public FileStatus DropboxHandler() throws Exception
    {
        //fHandler=new FileHandler();
        return fHandler.DropboxHandler();
    }
    public void SetInitialTime()
    {
        fHandler.setInitialLastModifiedDate();
    }
    public void SetInitialFileStatus()
    {
        fHandler.setFileStatus();
    }
		
    }
