/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filesystemclient;

/**
 *
 * @author Wasiq Ali Abbasi
 */
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class FileHandler {

    private String _filePath="test.txt";
    //private boolean _dropbox;
    private long _lastModifiedDate;
    private boolean _fileDeleted;
    private boolean _initiallyFileExists;

    public FileHandler(String fileName)
    {
        _filePath=fileName;
    }
    public FileHandler()
    {   
    }
    
    public byte [] HandleUploadFile() throws Exception
    {
        File myFile = new File (_filePath);
          byte [] mybytearray  = new byte [(int)myFile.length()];
          FileInputStream fis = null;
          BufferedInputStream bis = null;
          fis = new FileInputStream(myFile);
          bis = new BufferedInputStream(fis);
          bis.read(mybytearray,0,mybytearray.length);
          if (bis != null) bis.close();
          return mybytearray;

    }
    public void HandleDownloadFile(byte[] mybytearray, int size) throws Exception
    {
        int bytesRead;
    FileOutputStream fos = null;
    BufferedOutputStream bos = null;
      String line;
      fos = new FileOutputStream(_filePath);
      bos = new BufferedOutputStream(fos);
      bos.write(mybytearray, 0 , size);
      bos.flush();
       System.out.println("File " + _filePath
          + " downloaded (" + size + " bytes read)");
      if (fos != null) fos.close();
      if (bos != null) bos.close();
    }
    public FileStatus DropboxHandler()
    {
        File myFile = new File (_filePath);
        FileStatus fStatus=new FileStatus();
        if(myFile.exists()==false && _initiallyFileExists==false)
        {
            //file has not been created yet
            fStatus.setFileNotCreatedYet(true);
        }
        else if(myFile.exists()==false && _initiallyFileExists==true && _fileDeleted==false)
        {
            //file has been deleted
            _fileDeleted=true;
            fStatus.setFileDeleted(true);
        }
        else if(myFile.lastModified()!= _lastModifiedDate && _initiallyFileExists==true && _fileDeleted==false)
        {
            //file has been altered
            _lastModifiedDate=myFile.lastModified();
            fStatus.setFileAltered(true);
        }
        else if (myFile.exists() && _fileDeleted)
        {
            _fileDeleted=false;
            _initiallyFileExists=true;
            
            //file has been created
            fStatus.setFileCreated(true);
        }
        else fStatus.setFileStatusNotChanged(true);
       
        return fStatus;
    }
    public void setInitialLastModifiedDate() 
    {
        File myFile = new File (_filePath);
        this._lastModifiedDate = myFile.lastModified();
    }
    public void setFileStatus()
    {
        File myFile = new File (_filePath);
        if(myFile.exists()==false)
        {
        _initiallyFileExists=false;
        _fileDeleted=true;
        }
        else 
        {
            _initiallyFileExists=true;
            _fileDeleted=false;
        }
    }
    
}
