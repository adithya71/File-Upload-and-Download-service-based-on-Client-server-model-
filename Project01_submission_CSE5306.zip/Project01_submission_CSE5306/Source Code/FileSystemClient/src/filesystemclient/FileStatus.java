/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filesystemclient;

/**
 *
 * @author Wasiq Ali Abbasi
 */
public class FileStatus {

    /**
     * @return the _fileCreated
     */
    public boolean isFileCreated() {
        return _fileCreated;
    }

    /**
     * @param _fileCreated the _fileCreated to set
     */
    public void setFileCreated(boolean _fileCreated) {
        this._fileCreated = _fileCreated;
    }

    /**
     * @return the _fileAltered
     */
    public boolean isFileAltered() {
        return _fileAltered;
    }

    /**
     * @param _fileAltered the _fileAltered to set
     */
    public void setFileAltered(boolean _fileAltered) {
        this._fileAltered = _fileAltered;
    }

    /**
     * @return the _fileDeleted
     */
    public boolean isFileDeleted() {
        return _fileDeleted;
    }

    /**
     * @param _fileDeleted the _fileDeleted to set
     */
    public void setFileDeleted(boolean _fileDeleted) {
        this._fileDeleted = _fileDeleted;
    }
    private boolean _fileCreated;
    private boolean _fileAltered;
    private boolean _fileDeleted;
    private boolean _fileNotCreatedYet;
    private boolean _fileStatusNotChanged;

    /**
     * @return the _fileNotCreatedYet
     */
    public boolean isFileNotCreatedYet() {
        return _fileNotCreatedYet;
    }

    /**
     * @param _fileNotCreatedYet the _fileNotCreatedYet to set
     */
    public void setFileNotCreatedYet(boolean _fileNotCreatedYet) {
        this._fileNotCreatedYet = _fileNotCreatedYet;
    }

    /**
     * @return the _fileStatusNotChanged
     */
    public boolean isFileStatusNotChanged() {
        return _fileStatusNotChanged;
    }

    /**
     * @param _fileStatusNotChanged the _fileStatusNotChanged to set
     */
    public void setFileStatusNotChanged(boolean _fileStatusNotChanged) {
        this._fileStatusNotChanged = _fileStatusNotChanged;
    }
    
}
