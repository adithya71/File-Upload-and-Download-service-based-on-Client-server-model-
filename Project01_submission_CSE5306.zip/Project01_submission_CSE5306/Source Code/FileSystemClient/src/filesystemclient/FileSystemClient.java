/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filesystemclient;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author Wasiq Ali Abbasi
 */
public class FileSystemClient {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try
        {
            System.out.println("Do you want to keep the Dropbox Synchronization On or Off: ");
            BufferedReader userInputBR = new BufferedReader(new InputStreamReader(System.in));
            String userInput = userInputBR.readLine();
            ConnectionClient cClient=new ConnectionClient();
            
                        if(userInput.equalsIgnoreCase("on"))
                        {
                            System.out.println("The server will synchronize with the system every 15 seconds");
                            Thread thread = new Thread(new Runnable()
                            {
                                public void run()
                                {
                                    try{
                                        DropboxHandler(cClient);
                                    } 
                                    catch (Exception e)
                                    {
                                        
                                    }
                                }
                            });
                            thread.start();

                        }
        
                while (true) {
			System.out.println("Please enter the appropriate command : => \nUpload\n=> Download\n=> Delete\n=> Rename\n=> Exit");
        
			//BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			//PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

			//System.out.println("server says:" + br.readLine());

			userInputBR = new BufferedReader(new InputStreamReader(System.in));
			userInput = userInputBR.readLine();

			if ("exit".equalsIgnoreCase(userInput)) {
				cClient.CloseClientConnection();
				break;
			}
                        else if("upload".equalsIgnoreCase(userInput) || "download".equalsIgnoreCase(userInput) || "delete".equalsIgnoreCase(userInput) || "rename".equalsIgnoreCase(userInput))
                        {
                            cClient.EstablishClientConnection();
                            cClient.SendCommand(userInput);

                            if("upload".equalsIgnoreCase(userInput))
                            {
                                cClient.UploadFile();
                                cClient.CloseClientConnection();
                            }
                            else if("download".equalsIgnoreCase(userInput))
                            {
                                cClient.DownloadFile();
                                cClient.CloseClientConnection();
                                
                            }
                            else if("rename".equalsIgnoreCase(userInput))
                            {
                                System.out.println("New name: ");
                                userInputBR = new BufferedReader(new InputStreamReader(System.in));
                                userInput = userInputBR.readLine();
                                cClient.RenameFile(userInput);
                            }
                            
                        }
                        else
                        {
                            System.out.println("Invalid Command. Please try again to enter exit to end");
                        }               
            }
            

        }
        catch (Exception e)
                {
                    
                }
}
    public static void DropboxHandler(ConnectionClient cClient) throws Exception
    {
        cClient.SetInitialTime();
        cClient.SetInitialFileStatus();
        do{
            FileStatus fStatus=new FileStatus();
            Thread.sleep(15000);
            System.out.println("Synchronizing.....");
            fStatus=cClient.DropboxHandler();
            if(fStatus.isFileNotCreatedYet())
            {
                //cClient.EstablishClientConnection();
                System.out.println("[ALERT]: The file has not been created at Client side yet");
                //cClient.CloseClientConnection();
            }
            if(fStatus.isFileCreated())
            {
                cClient.EstablishClientConnection();
                System.out.println("[ALERT]: The file has been created. Uploading data from Server side");
                cClient.SendCommand("upload");
                cClient.UploadFile();
                cClient.CloseClientConnection();
            }
            else if(fStatus.isFileDeleted())
            {
                cClient.EstablishClientConnection();
                 System.out.println("[ALERT]: The file has been deleted. Deleting file from Server side");
                 cClient.SendCommand("delete");
                 cClient.CloseClientConnection();
            }
            else if(fStatus.isFileAltered())
            {
                cClient.EstablishClientConnection();
                 System.out.println("[ALERT]: The file has been altered. Uploading data to Server side ");
                 cClient.SendCommand("upload");
                 cClient.UploadFile();
                 cClient.CloseClientConnection();
            }
            else if(fStatus.isFileStatusNotChanged())
            {
                System.out.println("[ALERT]: The file status has not changed");
            }
            
            System.out.println("Client-Server Synchronized. Please continue your usual operations");
        }while(true);
    }
}
