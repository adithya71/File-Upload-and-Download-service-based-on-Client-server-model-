/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filesystemserver;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

/**
 *
 * @author Wasiq Ali Abbasi
 */
public class FileHandler {
private String _filePath= "test.txt";
public FileHandler()
{
    
   
}
public void HandleUploadFile(byte[] mybytearray, int size) throws Exception
{

      int bytesRead;
    //int current = 0;
    FileOutputStream fos = null;
    BufferedOutputStream bos = null;
      //mybytearray  = new byte [6022386];
      String line;
      fos = new FileOutputStream(_filePath);
      bos = new BufferedOutputStream(fos);
      bos.write(mybytearray, 0 , size);
      bos.flush();
       //System.out.println("File " + _filePath + " uploaded (" + size + " bytes read)");
    if (fos != null) fos.close();
    if (bos != null) bos.close();
     
}
public byte[] HandleDownloadFile() throws Exception
{
    File myFile = new File (_filePath);
          byte [] mybytearray  = new byte [(int)myFile.length()];
          FileInputStream fis = null;
          BufferedInputStream bis = null;
          fis = new FileInputStream(myFile);
          bis = new BufferedInputStream(fis);
          bis.read(mybytearray,0,mybytearray.length);
          if (bis != null) bis.close();
          return mybytearray;

          
}
public void DeleteFile()
{
    File myFile = new File (_filePath);
    myFile.delete();
}
public void RenameFile(String name)
{
    File oldFile = new File (_filePath);
    File newfile =new File(name);
    oldFile.renameTo(newfile);
   _filePath=name;
}
public void DropboxHandler()
{
    
}
}
