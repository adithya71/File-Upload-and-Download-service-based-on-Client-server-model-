/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filesystemserver;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author Wasiq Ali Abbasi
 */
public class FileSystemServer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try{
        Connection c=new Connection();
        System.out.println("Press 1 for single threaded, Press 2 for multithreaded: ");
        BufferedReader userInputBR = new BufferedReader(new InputStreamReader(System.in));
	String userInput = userInputBR.readLine();
        if(userInput.equalsIgnoreCase("1"))
        c.EstablishConnection(false);
        else if(userInput.equalsIgnoreCase("2"))
        c.EstablishConnection(true);
        else System.out.println("Invalid command. Server Initiation Failed. Run the Server again");
        }
        catch (Exception e)
        {
            
        }
        // TODO code application logic here
    }
    
}
