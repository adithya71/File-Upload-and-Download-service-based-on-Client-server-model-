/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package filesystemserver;

/**
 *
 * @author Wasiq Ali Abbasi
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.InputStream;

public class Connection {
//Socket socket;
FileHandler fHandler=new FileHandler();
ServerSocket serverSocket;
    public void EstablishConnection(boolean multithreaded)
    {
        final int portNumber = 8080;
        try
        {
            	System.out.println("Creating server socket on localhost port " + portNumber);
		serverSocket = new ServerSocket(portNumber);
        	while (true) {
			Socket socket = serverSocket.accept();
                        if(multithreaded!=true)
                        Handler(socket);
                        else
                        {
                            Thread thread = new Thread(new Runnable()
                            {
                                public void run()
                                {
                                    try{
                                    Handler(socket);
                                    } 
                                    catch (Exception e)
                                    {
                                        
                                    }
                                }
                            });
                            thread.start();
                        }
                             }
        }
        catch(Exception e)
        {
            
        }
	
	}

    public void Handler(Socket socket) throws Exception
    {
                        String str;
			BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			str = br.readLine();
                        System.out.println("[CLIENT]: Command Received: " + str);
                        OutputStream os = socket.getOutputStream();
			PrintWriter pw = new PrintWriter(os, true);
			pw.println("ACK Command Received");
			if(str.equalsIgnoreCase("upload"))
                        {
                            UploadFile(socket);
                        }
                        else if(str.equalsIgnoreCase("download"))
                        {
                            DownloadFile(socket);
                        }
                        else if(str.equalsIgnoreCase("delete"))
                        {
                            DeleteFile();
                        }
                        else if(str.equalsIgnoreCase("rename"))
                        {
                        //socket = serverSocket.accept();
			br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                        str=null;
                        do
                        {
			str = br.readLine();
                        }while(str==null);
                        RenameFile(str);
                        }
                        socket.close();
    }
    
    public void UploadFile(Socket socket) throws Exception
    {
        int bytesRead;
        byte [] mybytearray  = new byte [6022386];
        int current = 0;
        InputStream is = socket.getInputStream(); 
        do {
             bytesRead =
                is.read(mybytearray, current, (mybytearray.length-current));
             if(bytesRead >= 0) current += bytesRead;
           } while(bytesRead < -1);
        fHandler.HandleUploadFile(mybytearray, current);

    }
    public void DownloadFile(Socket socket) throws Exception
    {
        byte[] mybytearray= fHandler.HandleDownloadFile();
        System.out.println("[SERVER]: Downloading file to Client");
        OutputStream os = null;
        os = socket.getOutputStream();
        os.write(mybytearray,0,mybytearray.length);
        os.flush();
        if (os != null) os.close();
    }
    public void DeleteFile()
    {
        fHandler.DeleteFile();
    }
    public void RenameFile(String name)
    {
        fHandler.RenameFile(name);
    }

    }
    
